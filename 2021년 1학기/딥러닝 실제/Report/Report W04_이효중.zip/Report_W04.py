import matplotlib.pyplot as plt
from matplotlib.image import imread

img = imread('Hyojoong.jpg')

plt.imshow(img)
plt.show()
